/* Automatically generated from config.h: internal/compiler config. */

#define HAVE_SYS_TYPES_H 1
#define HAVE_UNISTD_H 1
#define PQXX_HAVE_GCC_VISIBILITY 1
